package com.matej.roadsurfacetopography.ui.homePage.dataMonitor

interface DataMonitorContract {
}