package com.matej.roadsurfacetopography.ui.homePage.dataList

interface DataListContract {
}