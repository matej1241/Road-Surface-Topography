package com.matej.roadsurfacetopography.common

typealias SuccessLambda<T> = (T) -> Unit
typealias ErrorLambda<T> = (T) -> Unit