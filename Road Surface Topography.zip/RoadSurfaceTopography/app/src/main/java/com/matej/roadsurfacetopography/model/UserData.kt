package com.matej.roadsurfacetopography.model

data class UserData(val email: String, val username: String = "", val password: String)